# 🛡️ SafeHer – Women Safety Web Application

A production-ready, fully responsive women safety web app built with **HTML, CSS, and JavaScript**.

---

## 📁 Folder Structure

```
women-safety-app/
├── index.html              # Main HTML entry point
├── css/
│   └── styles.css          # Full responsive stylesheet (dark/light mode)
├── js/
│   ├── config.js           # API keys, app config, environment variables
│   ├── auth.js             # Registration, login, session management
│   ├── location.js         # GPS tracking, Leaflet map, police station search
│   ├── sos.js              # SOS modal, SMS via Twilio, phone calls, log
│   ├── voice.js            # Web Speech API voice trigger detection
│   ├── recorder.js         # Audio/video recording via MediaRecorder API
│   ├── ui.js               # Toast notifications, navigation, theme, helpers
│   └── app.js              # Main bootstrap — wires all modules together
└── README.md
```

---

## 🚀 Quick Start

1. **Open `index.html`** in a modern browser (Chrome or Edge recommended).
2. Register an account (stored locally in your browser).
3. Enable location access when prompted.
4. Explore all features!

> ⚠️ For full SMS functionality, configure your **Twilio API keys** in `js/config.js`.

---

## ✨ Features

| Feature | Status | Notes |
|---|---|---|
| Login & Registration | ✅ Full | Hashed passwords via SubtleCrypto |
| Dark / Light Mode | ✅ Full | Auto-detects system preference |
| Live GPS Tracking | ✅ Full | Browser Geolocation API |
| Interactive Map | ✅ Full | Leaflet.js + OpenStreetMap |
| Nearby Police Stations | ✅ Full | Overpass API (OpenStreetMap data) |
| SOS Button (Hold 2s) | ✅ Full | Countdown modal + auto-activate |
| Emergency Calling | ✅ Full | `tel:` URI — opens native dialer |
| SMS Alerts | ✅ Demo / Real | Twilio API (configure keys) |
| Live Location Share | ✅ Full | Web Share API + clipboard fallback |
| Voice Trigger | ✅ Full | Web Speech API ("Help me", "Save me") |
| Video Recording | ✅ Full | MediaRecorder API, download evidence |
| Audio Recording | ✅ Full | MediaRecorder API, download evidence |
| Auto-record on SOS | ✅ Full | Auto-starts video on SOS activation |
| Profile Management | ✅ Full | Update name, phone, family contact |
| Responsive Design | ✅ Full | Mobile, tablet, desktop |
| Offline-friendly | ✅ Partial | Map requires internet |

---

## 🔑 API Configuration (`js/config.js`)

### Twilio SMS (Required for real SMS)

1. Sign up at [https://www.twilio.com](https://www.twilio.com) (free trial available)
2. Get your `Account SID`, `Auth Token`, and a Twilio phone number
3. Update `js/config.js`:

```js
TWILIO_ACCOUNT_SID: "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
TWILIO_AUTH_TOKEN:  "your_auth_token_here",
TWILIO_FROM_NUMBER: "+1XXXXXXXXXX",
```

> ⚠️ **Security Warning:** Never expose Twilio credentials in client-side code for production.
> Use a backend proxy (Node.js/Python/etc.) that receives requests from your app and calls Twilio server-side.

### Backend Proxy Example (Node.js)

```js
// server.js
const express = require('express');
const twilio  = require('twilio');
const app     = express();
app.use(express.json());

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

app.post('/api/send-sms', async (req, res) => {
  try {
    const msg = await client.messages.create({
      body: req.body.message,
      from: process.env.TWILIO_FROM,
      to:   req.body.to
    });
    res.json({ success: true, sid: msg.sid });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.listen(3000);
```

---

## 🌍 Emergency Numbers

Update `js/config.js` for your country:

| Country | Police | Ambulance |
|---|---|---|
| India | 112 | 108 |
| USA | 911 | 911 |
| UK | 999 | 999 |
| Europe | 112 | 112 |

---

## 🎙️ Voice Trigger Phrases

By default, SafeHer listens for:
- **"Help me"**
- **"Save me"**
- **"Emergency"**
- **"Help"**
- **"Bachao"** (Hindi)
- **"Mayday"**

Customize in `js/config.js` → `VOICE_TRIGGER_PHRASES`.

> Works best in **Google Chrome** on Android/Desktop.
> Voice recognition requires microphone permission.

---

## 🗺️ Police Station Detection

Uses **Overpass API** (OpenStreetMap) — **free, no API key needed**.

- Searches within 5km radius of user's location
- Shows station name, distance, phone number
- Click any station card to pan the map to it
- Falls back to a preset list (Bangalore) if API is unavailable

---

## 🔒 Security Notes

- Passwords are hashed using **SubtleCrypto SHA-256** (browser-native)
- In production: use **bcrypt/Argon2** on a backend server
- Use **HTTPS only** — Geolocation API requires HTTPS in production
- Store API keys in **environment variables** on your server, never in client JS
- Add **Content Security Policy** headers when deploying

---

## 🌐 Browser Compatibility

| Feature | Chrome | Firefox | Safari | Edge |
|---|---|---|---|---|
| Geolocation | ✅ | ✅ | ✅ | ✅ |
| MediaRecorder | ✅ | ✅ | ✅ (v14.5+) | ✅ |
| Web Speech API | ✅ | ❌ | ❌ | ✅ |
| Web Share API | ✅ | ✅ | ✅ | ✅ |
| SubtleCrypto | ✅ | ✅ | ✅ | ✅ |

---

## 📱 Deployment

### Static Hosting (Recommended)
- **Netlify**: Drag and drop the folder at netlify.com
- **Vercel**: `npx vercel` in the project folder
- **GitHub Pages**: Push to a repo and enable Pages

### Self-hosted
```bash
# Simple Python server for local testing
python3 -m http.server 8080

# Or Node.js
npx serve .
```

---

## 📄 License

MIT License — Free for personal and commercial use.

---

Built with ❤️ for women's safety. Stay safe, stay empowered. 💜
