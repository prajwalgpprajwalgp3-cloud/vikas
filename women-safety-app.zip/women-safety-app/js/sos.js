/**
 * SafeHer – sos.js
 * SOS emergency system: countdown modal, SMS via Twilio, phone calls, log.
 *
 * SMS via Twilio:
 *   ⚠️  Direct Twilio API calls from the browser expose your Auth Token.
 *       In production, route through your own backend server endpoint.
 *       Example backend: POST /api/send-sms  { to, message }
 *
 * Phone calls:
 *   The web cannot programmatically place phone calls for security reasons.
 *   We use tel: links which prompt the user's phone dialer.
 */

const SOSModule = (() => {
  // ── State ───────────────────────────────────────────────────
  let countdownTimer = null;
  let countdownSecs = CONFIG.SOS_COUNTDOWN_SECS;
  let isSOSActive = false;

  // ── SOS Flow ─────────────────────────────────────────────────

  /** Show the SOS confirmation modal with countdown */
  function showSOSConfirm() {
    const modal = document.getElementById("sos-modal");
    if (!modal) return;

    countdownSecs = CONFIG.SOS_COUNTDOWN_SECS;
    modal.classList.remove("hidden");
    _startCountdown();
  }

  function _startCountdown() {
    const numEl    = document.getElementById("countdown-number");
    const secsEl   = document.getElementById("countdown-secs");
    const progress = document.getElementById("countdown-progress");

    const circumference = 163.4; // 2 * PI * r(26)

    function update() {
      if (numEl)    numEl.textContent  = countdownSecs;
      if (secsEl)   secsEl.textContent = countdownSecs;
      if (progress) {
        const offset = circumference * (1 - countdownSecs / CONFIG.SOS_COUNTDOWN_SECS);
        progress.style.strokeDashoffset = offset;
      }

      if (countdownSecs <= 0) {
        clearInterval(countdownTimer);
        countdownTimer = null;
        cancelSOSModal();
        activateSOS();
        return;
      }
      countdownSecs--;
    }

    // Reset progress
    if (progress) progress.style.strokeDashoffset = "0";
    update();
    countdownTimer = setInterval(update, 1000);
  }

  /** Cancel the modal and stop countdown */
  function cancelSOSModal() {
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
    const modal = document.getElementById("sos-modal");
    if (modal) modal.classList.add("hidden");
  }

  /** Full SOS activation sequence */
  async function activateSOS() {
    if (isSOSActive) return;
    isSOSActive = true;

    cancelSOSModal();

    // Show SOS active overlay
    const overlay = document.getElementById("sos-active-overlay");
    if (overlay) overlay.classList.remove("hidden");

    const stepsEl = document.getElementById("sos-active-steps");
    const statusEl = document.getElementById("sos-active-status");

    // Update safety status
    UI.updateSafetyStatus(false);

    function addStep(icon, text, done = false) {
      if (!stepsEl) return;
      const el = document.createElement("div");
      el.className = `step-item${done ? " done" : ""}`;
      el.innerHTML = `<i class="fas fa-${icon}"></i> <span>${text}</span>`;
      stepsEl.appendChild(el);
      return el;
    }

    if (stepsEl) stepsEl.innerHTML = "";

    // Step 1: Get location
    if (statusEl) statusEl.textContent = "Getting your location...";
    addStep("location-arrow", "Fetching live GPS location...");

    let pos = LocationModule.getCurrentPosition();
    if (!pos) {
      try {
        pos = await _getCurrentPositionPromise();
      } catch {
        addStep("circle-xmark", "Location unavailable – sending alert without location.");
      }
    }
    if (pos) {
      addStep("map-marker-alt", `Location: ${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}`, true);
    }

    // Step 2: Log SOS event
    _addSOSLog("SOS activated", "triangle-exclamation");

    // Step 3: Send SMS to family
    if (statusEl) statusEl.textContent = "Sending SMS alerts...";
    addStep("message", "Sending SMS to family...");
    const user = Auth.getCurrentUser();
    const smsResult = await sendSMSAlert(pos);
    if (smsResult.success) {
      addStep("check-circle", "SMS sent to family member", true);
      _addSOSLog("SMS sent to family", "check-circle");
    } else {
      addStep("circle-xmark", `SMS: ${smsResult.message}`);
      _addSOSLog(`SMS failed: ${smsResult.message}`, "circle-xmark");
    }

    // Step 4: Share location link
    if (pos) {
      const link = `https://www.google.com/maps?q=${pos.lat},${pos.lng}`;
      addStep("share-nodes", `Location link ready: ${link}`, true);
      _addSOSLog("Location link generated", "map-marker-alt");
    }

    // Step 5: Auto-start recording
    if (typeof RecorderModule !== "undefined") {
      try {
        await RecorderModule.startVideoRecording();
        addStep("video", "Evidence recording started", true);
        _addSOSLog("Recording started automatically", "video");
      } catch {
        addStep("video-slash", "Auto-recording not available");
      }
    }

    if (statusEl) statusEl.textContent = "Emergency alerts sent! Help is on the way. 💪";

    // Play alert sound
    _playAlertBeep();
  }

  function deactivateSOS() {
    isSOSActive = false;
    const overlay = document.getElementById("sos-active-overlay");
    if (overlay) overlay.classList.add("hidden");
    UI.updateSafetyStatus(true);
    _addSOSLog("SOS cancelled by user", "circle-check");
    UI.showToast("SOS deactivated. Stay safe! 💜", "success");

    // Stop recording if it was auto-started
    if (typeof RecorderModule !== "undefined") RecorderModule.stopRecording();
  }

  // ── SMS via Twilio ────────────────────────────────────────────

  /**
   * Send SMS alert to the family member using Twilio.
   *
   * ⚠️ IMPORTANT: This demo calls Twilio directly from the browser.
   *    In production, POST to YOUR own backend which then calls Twilio.
   *    Your backend keeps the Auth Token secret.
   *
   * Backend example (Node.js Express):
   *   app.post('/api/send-sms', (req, res) => {
   *     const client = require('twilio')(SID, TOKEN);
   *     client.messages.create({ body: req.body.message, from: FROM, to: req.body.to })
   *       .then(m => res.json({ success: true, sid: m.sid }))
   *       .catch(e => res.status(500).json({ success: false, error: e.message }));
   *   });
   */
  async function sendSMSAlert(pos) {
    const user = Auth.getCurrentUser();
    if (!user) return { success: false, message: "User not authenticated." };

    const toNumber = user.familyPhone;
    if (!toNumber) return { success: false, message: "No family phone number found. Please update your profile." };

    const lat = pos?.lat || 0;
    const lng = pos?.lng || 0;
    const message = CONFIG.getSMSMessage(user.name, lat, lng);

    // Check if Twilio is configured
    if (CONFIG.TWILIO_ACCOUNT_SID === "YOUR_TWILIO_ACCOUNT_SID") {
      // Demo mode: simulate SMS
      console.log("[Demo SMS]\nTo:", toNumber, "\nMessage:", message);
      UI.showToast("SMS demo mode (Twilio not configured). Configure API keys in config.js", "warning");

      // Show what the SMS would say
      _showSMSPreview(toNumber, message);

      return { success: true, message: "SMS simulated (demo mode)." };
    }

    // Real Twilio API call (should go via your backend in production)
    try {
      const credentials = btoa(`${CONFIG.TWILIO_ACCOUNT_SID}:${CONFIG.TWILIO_AUTH_TOKEN}`);
      const url = `https://api.twilio.com/2010-04-01/Accounts/${CONFIG.TWILIO_ACCOUNT_SID}/Messages.json`;

      const body = new URLSearchParams({
        To: toNumber,
        From: CONFIG.TWILIO_FROM_NUMBER,
        Body: message
      });

      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Authorization": `Basic ${credentials}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: body.toString()
      });

      const data = await res.json();

      if (res.ok && data.sid) {
        return { success: true, message: `SMS sent! SID: ${data.sid}` };
      } else {
        return { success: false, message: data.message || "SMS failed." };
      }
    } catch (err) {
      console.error("Twilio error:", err);
      return { success: false, message: "Network error sending SMS." };
    }
  }

  /** Show a modal/toast with the SMS content in demo mode */
  function _showSMSPreview(to, message) {
    UI.showToast(`SMS would be sent to ${to}`, "info");
    console.group("📱 SafeHer – Emergency SMS Preview");
    console.log("To:", to);
    console.log("Message:\n" + message);
    console.groupEnd();
  }

  // ── Phone Calling ─────────────────────────────────────────────

  /** Initiate a phone call to police (uses tel: URI scheme) */
  function callPolice() {
    _addSOSLog(`Calling Police (${CONFIG.POLICE_NUMBER})...`, "phone");
    window.location.href = `tel:${CONFIG.POLICE_NUMBER}`;
  }

  /** Initiate a phone call to family member */
  function callFamily() {
    const user = Auth.getCurrentUser();
    const phone = user?.familyPhone;
    if (!phone) {
      UI.showToast("No family phone number. Please update your profile.", "warning");
      return;
    }
    _addSOSLog(`Calling family: ${phone}`, "phone-volume");
    window.location.href = `tel:${phone}`;
  }

  /** Share location link via Web Share API or clipboard */
  async function shareLocation() {
    const pos = LocationModule.getCurrentPosition();
    if (!pos) {
      UI.showToast("Enable location tracking first.", "warning");
      return;
    }

    const link = `https://www.google.com/maps?q=${pos.lat},${pos.lng}`;
    const shareData = {
      title: "🆘 SafeHer Emergency Location",
      text: `I need help! My location: ${link}`,
      url: link
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        _addSOSLog("Location shared via device", "share-nodes");
        UI.showToast("Location shared!", "success");
      } catch {
        _copyToClipboard(link);
      }
    } else {
      _copyToClipboard(link);
    }
  }

  function _copyToClipboard(text) {
    navigator.clipboard.writeText(text)
      .then(() => { UI.showToast("Location link copied to clipboard!", "success"); })
      .catch(() => {
        const ta = document.createElement("textarea");
        ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.focus(); ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        UI.showToast("Location link copied!", "success");
      });
  }

  // ── SOS Log ──────────────────────────────────────────────────

  function _addSOSLog(text, icon = "circle-info") {
    const container = document.getElementById("log-entries");
    if (!container) return;

    const empty = container.querySelector(".log-empty");
    if (empty) empty.remove();

    const entry = document.createElement("div");
    entry.className = "log-entry";
    const time = new Date().toLocaleTimeString();
    entry.innerHTML = `
      <i class="fas fa-${icon}"></i>
      <span>${text}</span>
      <span class="log-time">${time}</span>
    `;
    container.prepend(entry);
  }

  // ── Utilities ─────────────────────────────────────────────────

  function _getCurrentPositionPromise() {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        err => reject(err),
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });
  }

  function _playAlertBeep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.3, 0.6].forEach(delay => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.frequency.value = 880;
        osc.type = "sine";
        gain.gain.setValueAtTime(0.4, ctx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.25);
        osc.start(ctx.currentTime + delay);
        osc.stop(ctx.currentTime + delay + 0.3);
      });
    } catch { /* AudioContext may be unavailable */ }
  }

  // ── Public API ────────────────────────────────────────────────
  return {
    showSOSConfirm,
    cancelSOSModal,
    activateSOS,
    deactivateSOS,
    sendSMSAlert,
    callPolice,
    callFamily,
    shareLocation,
    isActive() { return isSOSActive; }
  };
})();
