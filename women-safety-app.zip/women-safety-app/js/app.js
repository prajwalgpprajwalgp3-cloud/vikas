/**
 * SafeHer – app.js
 * Main application entry point.
 * Bootstraps all modules, wires event listeners, and manages app lifecycle.
 */

(function () {
  "use strict";

  // ── Boot Sequence ─────────────────────────────────────────────

  document.addEventListener("DOMContentLoaded", () => {
    // 1. Init theme immediately (prevents flash)
    UI.initTheme();

    // 2. Show splash for ~2s then boot
    setTimeout(() => {
      UI.hideSplash(() => {
        if (Auth.isAuthenticated()) {
          _bootApp();
        } else {
          UI.showAuth();
          _bindAuthEvents();
        }
      });
    }, 2000);
  });

  // ── Auth Event Bindings ───────────────────────────────────────

  function _bindAuthEvents() {
    // Tab switching
    document.querySelectorAll(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => UI.switchAuthTab(btn.dataset.tab));
    });
    document.querySelectorAll(".switch-tab").forEach(link => {
      link.addEventListener("click", e => { e.preventDefault(); UI.switchAuthTab(link.dataset.to); });
    });

    // Password visibility toggles
    document.querySelectorAll(".toggle-pw").forEach(btn => {
      btn.addEventListener("click", () => {
        const input = document.getElementById(btn.dataset.target);
        if (!input) return;
        const isText = input.type === "text";
        input.type = isText ? "password" : "text";
        const icon = btn.querySelector("i");
        if (icon) icon.className = isText ? "fas fa-eye" : "fas fa-eye-slash";
      });
    });

    // Password strength meter
    const regPw = document.getElementById("reg-password");
    if (regPw) {
      regPw.addEventListener("input", () => UI.updatePasswordStrength(regPw.value));
    }

    // Login form
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
      loginForm.addEventListener("submit", async e => {
        e.preventDefault();
        UI.clearFormErrors("login-form");
        UI.setButtonLoading("login-btn", true);

        const email    = document.getElementById("login-email")?.value || "";
        const password = document.getElementById("login-password")?.value || "";

        const result = await Auth.login({ email, password });

        UI.setButtonLoading("login-btn", false);

        if (result.success) {
          UI.showToast(`Welcome back, ${result.user.name}! 💜`, "success");
          setTimeout(() => _bootApp(), 500);
        } else {
          if (result.field) UI.setFieldError(`login-${result.field}`, result.message);
          else UI.showToast(result.message, "error");
        }
      });
    }

    // Register form
    const registerForm = document.getElementById("register-form");
    if (registerForm) {
      registerForm.addEventListener("submit", async e => {
        e.preventDefault();
        UI.clearFormErrors("register-form");
        UI.setButtonLoading("register-btn", true);

        const data = {
          name:            document.getElementById("reg-name")?.value || "",
          email:           document.getElementById("reg-email")?.value || "",
          phone:           document.getElementById("reg-phone")?.value || "",
          familyPhone:     document.getElementById("reg-family-phone")?.value || "",
          password:        document.getElementById("reg-password")?.value || "",
          confirmPassword: document.getElementById("reg-confirm-password")?.value || ""
        };

        const result = await Auth.register(data);
        UI.setButtonLoading("register-btn", false);

        if (result.success) {
          UI.showToast(result.message, "success");
          UI.switchAuthTab("login");
          // Pre-fill login email
          const emailInput = document.getElementById("login-email");
          if (emailInput) emailInput.value = data.email;
        } else {
          if (result.field) {
            // Map field names to form IDs
            const fieldMap = {
              name: "reg-name",
              email: "reg-email",
              phone: "reg-phone",
              familyPhone: "reg-family-phone",
              password: "reg-password",
              confirmPassword: "reg-confirm-password"
            };
            UI.setFieldError(fieldMap[result.field] || result.field, result.message);
          } else {
            UI.showToast(result.message, "error");
          }
        }
      });
    }
  }

  // ── App Boot ──────────────────────────────────────────────────

  function _bootApp() {
    const user = Auth.getCurrentUser();
    UI.showApp(user);
    _bindAppEvents();
    _initMap();
    UI.navigateTo("dashboard");
    UI.showToast(`Welcome, ${user?.name?.split(" ")[0] || "Friend"}! Stay safe. 💜`, "success", 3000);
  }

  // ── Map Init (lazy, only when page is first shown) ────────────

  let mapInitialized = false;
  function _ensureMapReady() {
    if (!mapInitialized) {
      LocationModule.initMap();
      mapInitialized = true;
    }
    setTimeout(() => LocationModule.refreshMap?.(), 200);
  }

  function _initMap() {
    // Initialize on first map page visit
    document.querySelectorAll(".bnav-btn, .app-nav-btn").forEach(btn => {
      if (btn.dataset.page === "map-page") {
        btn.addEventListener("click", () => {
          _ensureMapReady();
        }, { once: false });
      }
    });
  }

  // ── App Event Bindings ────────────────────────────────────────

  function _bindAppEvents() {
    // ── Bottom Navigation ──
    document.querySelectorAll(".bnav-btn, .app-nav-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const page = btn.dataset.page;
        if (page === "sos") {
          // SOS nav button immediately shows SOS confirm
          UI.navigateTo("sos");
        } else {
          UI.navigateTo(page);
        }
        if (page === "map-page") _ensureMapReady();
      });
    });

    // ── Theme Toggle ──
    document.getElementById("theme-toggle")?.addEventListener("click", UI.toggleTheme);

    // ── Logout (navbar) ──
    document.getElementById("logout-btn")?.addEventListener("click", _logout);
    document.getElementById("logout-profile-btn")?.addEventListener("click", _logout);

    // ── SOS Buttons (dashboard + SOS page) ──
    UI.initSOSButton("sos-btn", SOSModule.showSOSConfirm);
    UI.initSOSButton("sos-btn-page", SOSModule.showSOSConfirm);

    // ── SOS Modal ──
    document.getElementById("confirm-sos-btn")?.addEventListener("click", () => {
      SOSModule.cancelSOSModal();
      SOSModule.activateSOS();
    });
    document.getElementById("cancel-sos-btn")?.addEventListener("click", SOSModule.cancelSOSModal);

    // ── SOS Active Overlay – Cancel ──
    document.getElementById("cancel-sos-active-btn")?.addEventListener("click", SOSModule.deactivateSOS);

    // ── SOS Page Actions ──
    const callPoliceLabel = document.getElementById("call-police-label");
    if (callPoliceLabel) callPoliceLabel.textContent = `Call Police (${CONFIG.POLICE_NUMBER})`;

    document.getElementById("call-police-btn")?.addEventListener("click", () => {
      SOSModule.callPolice();
      UI.showToast(`Opening dialer for Police (${CONFIG.POLICE_NUMBER})...`, "info");
    });
    document.getElementById("call-family-btn")?.addEventListener("click", () => {
      SOSModule.callFamily();
      UI.showToast("Opening dialer for family member...", "info");
    });
    document.getElementById("send-sms-btn")?.addEventListener("click", async () => {
      UI.showToast("Sending emergency SMS...", "info");
      const pos = LocationModule.getCurrentPosition();
      const result = await SOSModule.sendSMSAlert(pos);
      UI.showToast(result.message, result.success ? "success" : "error");
    });
    document.getElementById("share-location-btn")?.addEventListener("click", SOSModule.shareLocation);

    // ── Map Controls ──
    document.getElementById("start-tracking-btn")?.addEventListener("click", () => {
      if (LocationModule.isTracking()) {
        LocationModule.stopTracking();
        document.getElementById("start-tracking-btn").innerHTML =
          '<i class="fas fa-location-arrow"></i> Start Tracking';
        UI.showToast("Location tracking stopped.", "info");
      } else {
        const started = LocationModule.startTracking(
          pos => {
            // Optional: update status on each position update
          },
          err => {
            UI.showToast("Location error: " + err.message, "error");
          }
        );
        if (started) {
          document.getElementById("start-tracking-btn").innerHTML =
            '<i class="fas fa-stop"></i> Stop Tracking';
          UI.showToast("📍 Location tracking started.", "success");
        }
      }
    });

    document.getElementById("find-police-btn")?.addEventListener("click", () => {
      LocationModule.findNearbyPoliceStations();
    });

    document.getElementById("center-map-btn")?.addEventListener("click", LocationModule.centerMap);

    // ── Dashboard Quick Actions ──
    document.getElementById("qa-location-btn")?.addEventListener("click", () => {
      UI.navigateTo("map-page");
      _ensureMapReady();
    });
    document.getElementById("qa-record-btn")?.addEventListener("click",   () => UI.navigateTo("record-page"));
    document.getElementById("qa-voice-btn")?.addEventListener("click",    _toggleVoice);
    document.getElementById("qa-contacts-btn")?.addEventListener("click", () => {
      SOSModule.callFamily();
    });

    // ── Voice Activation Toggle (navbar) ──
    document.getElementById("voice-toggle-btn")?.addEventListener("click", _toggleVoice);

    // ── Recording Controls ──
    document.getElementById("start-video-btn")?.addEventListener("click", () => {
      RecorderModule.startVideoRecording();
    });
    document.getElementById("start-audio-btn")?.addEventListener("click", () => {
      RecorderModule.startAudioRecording();
    });
    document.getElementById("stop-record-btn")?.addEventListener("click", () => {
      RecorderModule.stopRecording();
      UI.showToast("Recording stopped and saved.", "success");
    });

    // ── Profile Save ──
    document.getElementById("save-profile-btn")?.addEventListener("click", () => {
      const name        = document.getElementById("profile-name")?.value || "";
      const phone       = document.getElementById("profile-phone")?.value || "";
      const familyPhone = document.getElementById("profile-family-phone")?.value || "";

      const result = Auth.updateProfile({ name, phone, familyPhone });

      if (result.success) {
        // Refresh displayed user info
        const updated = Auth.getCurrentUser();
        UI.showApp(updated);
        UI.showToast(result.message, "success");
      } else {
        UI.showToast(result.message, "error");
      }
    });

    // ── Close modal on overlay click ──
    document.getElementById("sos-modal")?.addEventListener("click", e => {
      if (e.target.id === "sos-modal") SOSModule.cancelSOSModal();
    });

    // ── Keyboard shortcuts ──
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") {
        SOSModule.cancelSOSModal();
        SOSModule.deactivateSOS();
      }
    });
  }

  // ── Voice ─────────────────────────────────────────────────────

  function _toggleVoice() {
    VoiceModule.toggleListening(phrase => {
      // Voice triggered SOS
      UI.showToast(`Voice trigger: "${phrase}" – activating SOS!`, "error", 5000);
      SOSModule.activateSOS();
    });
  }

  // ── Logout ────────────────────────────────────────────────────

  function _logout() {
    // Stop all active services
    LocationModule.stopTracking();
    VoiceModule.stopListening();
    RecorderModule.stopRecording();
    SOSModule.deactivateSOS();

    Auth.logout();
    UI.showAuth();
    _bindAuthEvents();
    UI.showToast("You have been logged out. Stay safe! 💜", "info");
  }

})();
