/**
 * SafeHer – config.js
 * Central configuration and environment variables.
 * ⚠️  Replace placeholder values with real API keys before deployment.
 * ⚠️  In production, NEVER expose sensitive keys in client-side code.
 *      Use a server-side backend/proxy to protect API keys.
 */

const CONFIG = {
  // ── App Info ──────────────────────────────────────────────────
  APP_NAME: "SafeHer",
  APP_VERSION: "1.0.0",

  // ── Emergency Contacts (override with real numbers) ──────────
  POLICE_NUMBER: "112",           // Police emergency number
  AMBULANCE_NUMBER: "108",        // India Ambulance
  EMERGENCY_NUMBER: "112",        // Universal emergency

  // ── Twilio SMS Configuration ─────────────────────────────────
  // Sign up at https://www.twilio.com – get free trial credits
  // ⚠️ For production, calls should go through your own backend server
  TWILIO_ACCOUNT_SID: "YOUR_TWILIO_ACCOUNT_SID",
  TWILIO_AUTH_TOKEN: "YOUR_TWILIO_AUTH_TOKEN",
  TWILIO_FROM_NUMBER: "+1XXXXXXXXXX",   // Your Twilio number

  // ── OpenCage Geocoding API (free tier available) ──────────────
  // Sign up at https://opencagedata.com
  OPENCAGE_API_KEY: "YOUR_OPENCAGE_API_KEY",

  // ── Overpass API (OpenStreetMap) – free, no key needed ────────
  OVERPASS_API_URL: "https://overpass-api.de/api/interpreter",

  // ── Map Settings ─────────────────────────────────────────────
  MAP_TILE_URL: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
  MAP_ATTRIBUTION: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  MAP_DEFAULT_ZOOM: 15,
  MAP_POLICE_SEARCH_RADIUS_M: 5000,   // 5 km radius for police search
  MAP_POLICE_RESULT_LIMIT: 0,          // 0 = show all stations found within radius
  LOCATION_LOW_ACCURACY_M: 1000,
  LOCATION_STALE_MS: 30000,

  // ── Voice Recognition Trigger Phrases ─────────────────────────
  VOICE_TRIGGER_PHRASES: ["help me", "save me", "emergency", "help", "bachao", "mayday"],

  // ── SOS Countdown (seconds before auto-activation) ────────────
  SOS_COUNTDOWN_SECS: 5,

  // ── Storage Keys ─────────────────────────────────────────────
  STORAGE_KEY_USER: "safeher_user",
  STORAGE_KEY_USERS_DB: "safeher_users_db",
  STORAGE_KEY_THEME: "safeher_theme",

  // ── SMS Template ─────────────────────────────────────────────
  getSMSMessage(name, lat, lng) {
    const mapsLink = `https://www.google.com/maps?q=${lat},${lng}`;
    return `🆘 EMERGENCY ALERT from SafeHer!\n\n` +
           `${name || "A SafeHer user"} needs immediate help!\n` +
           `📍 Live Location: ${mapsLink}\n` +
           `Coordinates: ${lat.toFixed(6)}, ${lng.toFixed(6)}\n\n` +
           `Please call them or contact emergency services (${CONFIG.POLICE_NUMBER}) immediately.\n` +
           `— SafeHer Safety App`;
  }
};

// Freeze config to prevent accidental modification
Object.freeze(CONFIG);
