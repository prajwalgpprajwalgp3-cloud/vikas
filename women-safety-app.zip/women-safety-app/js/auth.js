/**
 * SafeHer – auth.js
 * Authentication: registration, login, session management.
 * Uses localStorage as a simulated user database.
 * In production, replace with a secure backend API + JWT tokens.
 */

const Auth = (() => {
  // ── Private helpers ──────────────────────────────────────────
  
  /**
   * Hash a password using a simple SHA-256 via SubtleCrypto.
   * In production, use bcrypt or Argon2 on the server side.
   */
  async function hashPassword(password) {
    if (typeof crypto === "undefined" || !crypto.subtle) return fallbackHash(password);

    const encoder = new TextEncoder();
    const data = encoder.encode(password + "_safeher_salt_2024");
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  }

  function fallbackHash(password) {
    const text = password + "_safeher_salt_2024";
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return `demo-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  /** Load the simulated users database from localStorage */
  function loadUsersDB() {
    const raw = localStorage.getItem(CONFIG.STORAGE_KEY_USERS_DB);
    return raw ? JSON.parse(raw) : {};
  }

  /** Persist the users database to localStorage */
  function saveUsersDB(db) {
    localStorage.setItem(CONFIG.STORAGE_KEY_USERS_DB, JSON.stringify(db));
  }

  /** Sanitize and trim a string input */
  function sanitize(str) {
    return String(str || "").trim();
  }

  // ── Validation ───────────────────────────────────────────────

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  function validatePhone(phone) {
    const cleaned = phone.replace(/[\s\-()]/g, "");
    return /^\+?[0-9]{7,15}$/.test(cleaned);
  }

  function validatePassword(pw) {
    return pw.length >= 8;
  }

  // ── Public API ───────────────────────────────────────────────

  /**
   * Register a new user.
   * @returns {Promise<{success: boolean, message: string}>}
   */
  async function register({ name, email, password, confirmPassword, phone, familyPhone }) {
    name         = sanitize(name);
    email        = sanitize(email).toLowerCase();
    password     = sanitize(password);
    confirmPassword = sanitize(confirmPassword);
    phone        = sanitize(phone);
    familyPhone  = sanitize(familyPhone);

    // Validation
    if (!name)                          return { success: false, field: "name",            message: "Full name is required." };
    if (!validateEmail(email))          return { success: false, field: "email",           message: "Enter a valid email address." };
    if (!validatePhone(phone))          return { success: false, field: "phone",           message: "Enter a valid phone number with country code." };
    if (!validatePhone(familyPhone))    return { success: false, field: "familyPhone",     message: "Enter a valid family member phone number." };
    if (!validatePassword(password))    return { success: false, field: "password",        message: "Password must be at least 8 characters." };
    if (password !== confirmPassword)   return { success: false, field: "confirmPassword", message: "Passwords do not match." };

    const db = loadUsersDB();
    if (db[email]) return { success: false, field: "email", message: "An account with this email already exists." };

    const hashed = await hashPassword(password);
    db[email] = { name, email, phone, familyPhone, passwordHash: hashed, createdAt: new Date().toISOString() };
    saveUsersDB(db);

    return { success: true, message: "Account created successfully! Please sign in." };
  }

  /**
   * Login an existing user.
   * @returns {Promise<{success: boolean, user?: object, message: string}>}
   */
  async function login({ email, password }) {
    email    = sanitize(email).toLowerCase();
    password = sanitize(password);

    if (!email)    return { success: false, field: "email",    message: "Email is required." };
    if (!password) return { success: false, field: "password", message: "Password is required." };

    const db = loadUsersDB();
    const user = db[email];
    if (!user) return { success: false, field: "email", message: "No account found with this email." };

    const hashed = await hashPassword(password);
    if (hashed !== user.passwordHash) return { success: false, field: "password", message: "Incorrect password. Please try again." };

    // Store session (exclude passwordHash)
    const session = { name: user.name, email: user.email, phone: user.phone, familyPhone: user.familyPhone };
    localStorage.setItem(CONFIG.STORAGE_KEY_USER, JSON.stringify(session));

    return { success: true, user: session, message: "Welcome back!" };
  }

  /** Logout the current user */
  function logout() {
    localStorage.removeItem(CONFIG.STORAGE_KEY_USER);
  }

  /** Get the current logged-in user (or null) */
  function getCurrentUser() {
    const raw = localStorage.getItem(CONFIG.STORAGE_KEY_USER);
    return raw ? JSON.parse(raw) : null;
  }

  /** Check if a user is authenticated */
  function isAuthenticated() {
    return getCurrentUser() !== null;
  }

  /**
   * Update user profile fields.
   * @returns {{success: boolean, message: string}}
   */
  function updateProfile({ name, phone, familyPhone }) {
    const session = getCurrentUser();
    if (!session) return { success: false, message: "Not authenticated." };

    name        = sanitize(name)        || session.name;
    phone       = sanitize(phone)       || session.phone;
    familyPhone = sanitize(familyPhone) || session.familyPhone;

    if (phone && !validatePhone(phone))             return { success: false, message: "Invalid phone number." };
    if (familyPhone && !validatePhone(familyPhone)) return { success: false, message: "Invalid family phone number." };

    const db = loadUsersDB();
    if (db[session.email]) {
      db[session.email] = { ...db[session.email], name, phone, familyPhone };
      saveUsersDB(db);
    }

    const updated = { ...session, name, phone, familyPhone };
    localStorage.setItem(CONFIG.STORAGE_KEY_USER, JSON.stringify(updated));

    return { success: true, message: "Profile updated successfully!" };
  }

  /** Password strength checker (0–4) */
  function passwordStrength(pw) {
    let score = 0;
    if (pw.length >= 8)  score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return Math.min(score, 4);
  }

  return { register, login, logout, getCurrentUser, isAuthenticated, updateProfile, passwordStrength };
})();
