/**
 * SafeHer – recorder.js
 * Audio and video recording using MediaRecorder API.
 * Supports camera/mic access, timed recording, download of evidence.
 */

const RecorderModule = (() => {
  // ── State ───────────────────────────────────────────────────
  let mediaRecorder   = null;
  let recordedChunks  = [];
  let stream          = null;
  let recordingType   = null;   // "video" | "audio"
  let timerInterval   = null;
  let elapsedSeconds  = 0;
  const recordings    = [];     // { id, type, blob, url, name, size, timestamp }

  // ── Stream Management ─────────────────────────────────────────

  async function _getVideoStream() {
    return navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: true
    });
  }

  async function _getAudioStream() {
    return navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  }

  function _stopStream() {
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      stream = null;
    }
    const video = document.getElementById("video-preview");
    if (video) video.srcObject = null;
    const overlay = document.getElementById("video-overlay");
    if (overlay) overlay.classList.remove("hidden");
  }

  // ── Recording ─────────────────────────────────────────────────

  async function startVideoRecording() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      UI.showToast("Recording is already in progress.", "warning");
      return;
    }

    try {
      stream = await _getVideoStream();
      recordingType = "video";
      _attachVideoPreview(stream);
      _startMediaRecorder(stream, "video/webm;codecs=vp9,opus");
      UI.showToast("📹 Video recording started.", "success");
    } catch (err) {
      _handleMediaError(err, "camera/microphone");
    }
  }

  async function startAudioRecording() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      UI.showToast("Recording is already in progress.", "warning");
      return;
    }

    try {
      stream = await _getAudioStream();
      recordingType = "audio";
      _startMediaRecorder(stream, "audio/webm;codecs=opus");
      UI.showToast("🎙️ Audio recording started.", "success");
    } catch (err) {
      _handleMediaError(err, "microphone");
    }
  }

  function stopRecording() {
    if (!mediaRecorder || mediaRecorder.state === "inactive") return;
    mediaRecorder.stop();
  }

  function _startMediaRecorder(mediaStream, mimeType) {
    recordedChunks = [];
    elapsedSeconds = 0;

    // Use supported MIME type
    const supportedMime = MediaRecorder.isTypeSupported(mimeType)
      ? mimeType
      : (recordingType === "video" ? "video/webm" : "audio/webm");

    mediaRecorder = new MediaRecorder(mediaStream, { mimeType: supportedMime });

    mediaRecorder.ondataavailable = e => {
      if (e.data && e.data.size > 0) recordedChunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
      _stopStream();
      _saveRecording();
      _stopTimer();
      _updateRecordUI(false);
    };

    mediaRecorder.onerror = e => {
      console.error("[RecorderModule] MediaRecorder error:", e.error);
      UI.showToast("Recording error: " + e.error.message, "error");
    };

    mediaRecorder.start(100); // Collect data every 100ms

    _updateRecordUI(true);
    _startTimer();
  }

  function _attachVideoPreview(mediaStream) {
    const video = document.getElementById("video-preview");
    const overlay = document.getElementById("video-overlay");
    if (video) {
      video.srcObject = mediaStream;
      video.play().catch(() => {});
    }
    if (overlay) overlay.classList.add("hidden");
  }

  // ── Save & Download ──────────────────────────────────────────

  function _saveRecording() {
    if (recordedChunks.length === 0) return;

    const isVideo = recordingType === "video";
    const blob = new Blob(recordedChunks, { type: isVideo ? "video/webm" : "audio/webm" });
    const url  = URL.createObjectURL(blob);
    const ext  = isVideo ? "webm" : "webm";
    const ts   = new Date();
    const name = `safeher_${isVideo ? "video" : "audio"}_${ts.toISOString().replace(/[:.]/g, "-")}.${ext}`;
    const size = _formatBytes(blob.size);

    const record = { id: Date.now(), type: recordingType, blob, url, name, size, timestamp: ts };
    recordings.push(record);

    _renderRecordingItem(record);
    recordedChunks = [];
    UI.showToast(`✅ ${isVideo ? "Video" : "Audio"} saved (${size}).`, "success");
  }

  function downloadRecording(id) {
    const rec = recordings.find(r => r.id === id);
    if (!rec) return;
    const a = document.createElement("a");
    a.href = rec.url;
    a.download = rec.name;
    a.click();
    UI.showToast("Downloading recording...", "info");
  }

  // ── UI ────────────────────────────────────────────────────────

  function _renderRecordingItem(rec) {
    const container = document.getElementById("recordings-container");
    if (!container) return;

    const empty = container.querySelector(".empty-state");
    if (empty) empty.remove();

    const isVideo = rec.type === "video";
    const div = document.createElement("div");
    div.className = "recording-item";
    div.dataset.id = rec.id;
    div.innerHTML = `
      <div class="rec-item-icon ${isVideo ? "video" : "audio"}">
        <i class="fas fa-${isVideo ? "video" : "microphone"}"></i>
      </div>
      <div class="rec-item-info">
        <strong>${rec.name}</strong>
        <small>${rec.timestamp.toLocaleString()} · ${rec.size}</small>
      </div>
      <div class="rec-item-actions">
        <button class="rec-dl-btn" data-id="${rec.id}" title="Download">
          <i class="fas fa-download"></i> Save
        </button>
      </div>
    `;
    div.querySelector(".rec-dl-btn").addEventListener("click", () => downloadRecording(rec.id));
    container.prepend(div);
  }

  function _updateRecordUI(isRecording) {
    const startVideoBtn = document.getElementById("start-video-btn");
    const startAudioBtn = document.getElementById("start-audio-btn");
    const stopBtn       = document.getElementById("stop-record-btn");
    const indicator     = document.getElementById("rec-indicator");
    const timerEl       = document.getElementById("rec-timer");

    if (startVideoBtn) startVideoBtn.classList.toggle("hidden", isRecording);
    if (startAudioBtn) startAudioBtn.classList.toggle("hidden", isRecording);
    if (stopBtn)       stopBtn.classList.toggle("hidden", !isRecording);
    if (indicator)     indicator.classList.toggle("hidden", !isRecording);
    if (timerEl)       timerEl.classList.toggle("hidden", !isRecording);
  }

  // ── Timer ─────────────────────────────────────────────────────

  function _startTimer() {
    const timerEl = document.getElementById("rec-timer");
    timerInterval = setInterval(() => {
      elapsedSeconds++;
      if (timerEl) timerEl.textContent = _formatTime(elapsedSeconds);
    }, 1000);
  }

  function _stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    elapsedSeconds = 0;
    const timerEl = document.getElementById("rec-timer");
    if (timerEl) timerEl.textContent = "00:00";
  }

  // ── Error Handling ────────────────────────────────────────────

  function _handleMediaError(err, deviceName) {
    if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
      UI.showToast(`${deviceName} access denied. Please allow permission in your browser settings.`, "error");
    } else if (err.name === "NotFoundError") {
      UI.showToast(`No ${deviceName} found on this device.`, "error");
    } else if (err.name === "NotSupportedError") {
      UI.showToast(`${deviceName} is not supported in this browser.`, "error");
    } else {
      UI.showToast(`Could not access ${deviceName}: ${err.message}`, "error");
    }
    console.error("[RecorderModule] Media error:", err);
  }

  // ── Utilities ─────────────────────────────────────────────────

  function _formatTime(secs) {
    const m = String(Math.floor(secs / 60)).padStart(2, "0");
    const s = String(secs % 60).padStart(2, "0");
    return `${m}:${s}`;
  }

  function _formatBytes(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

  // ── Public API ────────────────────────────────────────────────
  return {
    startVideoRecording,
    startAudioRecording,
    stopRecording,
    downloadRecording,
    isRecording() { return mediaRecorder && mediaRecorder.state === "recording"; }
  };
})();
