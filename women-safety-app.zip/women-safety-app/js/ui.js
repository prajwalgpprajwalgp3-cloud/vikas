/**
 * SafeHer – ui.js
 * Shared UI utilities: toast notifications, status updates,
 * theme toggling, navigation, and DOM helpers.
 */

const UI = (() => {
  // ── Toast Notifications ──────────────────────────────────────

  const TOAST_ICONS = {
    success: "circle-check",
    error:   "circle-xmark",
    warning: "triangle-exclamation",
    info:    "circle-info"
  };

  /**
   * Show a toast notification.
   * @param {string} message  - Message text
   * @param {"success"|"error"|"warning"|"info"} type
   * @param {number} duration - Auto-dismiss ms (default: 4000)
   */
  function showToast(message, type = "info", duration = 4000) {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${TOAST_ICONS[type]}"></i><span>${message}</span>`;

    container.appendChild(toast);

    // Auto-dismiss
    const timer = setTimeout(() => dismissToast(toast), duration);

    // Click to dismiss
    toast.addEventListener("click", () => {
      clearTimeout(timer);
      dismissToast(toast);
    });
  }

  function dismissToast(toast) {
    toast.classList.add("toast-out");
    toast.addEventListener("animationend", () => toast.remove(), { once: true });
    setTimeout(() => toast.remove(), 400); // fallback
  }

  // ── Status Bar Updates ────────────────────────────────────────

  function updateStatus(elementId, active, text) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.classList.toggle("active", active);
    const span = el.querySelector("span");
    if (span) span.textContent = text;
  }

  function updateSafetyStatus(isSafe) {
    const el = document.getElementById("safety-status");
    if (!el) return;
    el.className = `status-item${isSafe ? " safe-indicator" : " sos-active-status"}`;
    el.innerHTML = isSafe
      ? `<i class="fas fa-shield-check"></i><span>Status: Safe</span>`
      : `<i class="fas fa-triangle-exclamation"></i><span>Status: SOS ACTIVE</span>`;
  }

  // ── Page Navigation ───────────────────────────────────────────

  function navigateTo(pageId) {
    // Hide all pages
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    // Show target
    const page = document.getElementById(pageId);
    if (page) {
      page.classList.add("active");
      // Scroll to top
      document.querySelector(".main-content")?.scrollTo({ top: 0, behavior: "smooth" });
    }

    // Update bottom nav active state
    document.querySelectorAll(".bnav-btn, .app-nav-btn").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.page === pageId);
    });

    // Special actions on page enter
    if (pageId === "map-page") {
      setTimeout(() => LocationModule.refreshMap?.(), 200);
    }
  }

  // ── Theme Management ─────────────────────────────────────────

  function initTheme() {
    const stored = localStorage.getItem(CONFIG.STORAGE_KEY_THEME);
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const theme = stored || (prefersDark ? "dark" : "light");
    setTheme(theme, false);
  }

  function setTheme(theme, save = true) {
    document.documentElement.setAttribute("data-theme", theme);
    const btn = document.getElementById("theme-toggle");
    if (btn) {
      const icon = btn.querySelector("i");
      if (icon) icon.className = theme === "dark" ? "fas fa-sun" : "fas fa-moon";
      btn.title = `Switch to ${theme === "dark" ? "Light" : "Dark"} Mode`;
    }
    if (save) localStorage.setItem(CONFIG.STORAGE_KEY_THEME, theme);
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme");
    setTheme(current === "dark" ? "light" : "dark");
  }

  // ── Auth UI ───────────────────────────────────────────────────

  function showAuth() {
    document.getElementById("auth-section")?.classList.remove("hidden");
    document.getElementById("app")?.classList.add("hidden");
  }

  function showApp(user) {
    document.getElementById("auth-section")?.classList.add("hidden");
    document.getElementById("app")?.classList.remove("hidden");

    // Update user info in nav
    if (user) {
      const initials = user.name
        ? user.name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2)
        : "U";

      const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
      setEl("nav-username", user.name || "User");
      setEl("user-avatar-initials", initials);
      setEl("hero-name", user.name?.split(" ")[0] || "Friend");
      setEl("profile-avatar-initials", initials);
      setEl("profile-name-display", user.name || "");
      setEl("profile-email-display", user.email || "");

      // Populate profile form
      const setInput = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ""; };
      setInput("profile-name", user.name);
      setInput("profile-email", user.email);
      setInput("profile-phone", user.phone);
      setInput("profile-family-phone", user.familyPhone);
    }
  }

  function switchAuthTab(tab) {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    document.querySelectorAll(".auth-form-wrap").forEach(f => f.classList.toggle("active", f.id === `${tab}-tab`));
  }

  // ── Form Helpers ──────────────────────────────────────────────

  function setFieldError(fieldId, message) {
    const errEl = document.getElementById(`${fieldId}-err`);
    const input = document.getElementById(fieldId);
    if (errEl) errEl.textContent = message;
    if (input) input.classList.toggle("error", Boolean(message));
  }

  function clearFormErrors(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.querySelectorAll(".field-error").forEach(e => e.textContent = "");
    form.querySelectorAll("input").forEach(i => i.classList.remove("error"));
  }

  function setButtonLoading(btnId, loading) {
    const btn  = document.getElementById(btnId);
    if (!btn) return;
    const text = btn.querySelector(".btn-text");
    const loader = btn.querySelector(".btn-loader");
    btn.disabled = loading;
    if (text)   text.classList.toggle("hidden", loading);
    if (loader) loader.classList.toggle("hidden", !loading);
  }

  // ── SOS Hold Behavior ─────────────────────────────────────────

  function initSOSButton(btnId, onHold) {
    const btn = document.getElementById(btnId);
    if (!btn) return;

    let holdTimer = null;
    const HOLD_MS = 2000;

    function startHold() {
      btn.classList.add("pressed");
      holdTimer = setTimeout(() => {
        btn.classList.remove("pressed");
        onHold();
      }, HOLD_MS);
    }

    function cancelHold() {
      if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
      btn.classList.remove("pressed");
    }

    btn.addEventListener("mousedown",   startHold);
    btn.addEventListener("touchstart",  startHold,  { passive: true });
    btn.addEventListener("mouseup",     cancelHold);
    btn.addEventListener("mouseleave",  cancelHold);
    btn.addEventListener("touchend",    cancelHold);
    btn.addEventListener("touchcancel", cancelHold);
  }

  // ── Password Strength UI ──────────────────────────────────────

  function updatePasswordStrength(password) {
    const score = Auth.passwordStrength(password);
    const fillEl  = document.getElementById("strength-fill");
    const labelEl = document.getElementById("strength-label");
    if (!fillEl || !labelEl) return;

    const widths = ["0%", "25%", "50%", "75%", "100%"];
    const colors = ["transparent", "#e53e3e", "#ed8936", "#ecc94b", "#38a169"];
    const labels = ["Enter password", "Too weak", "Weak", "Good", "Strong 💪"];

    fillEl.style.width  = widths[score];
    fillEl.style.background = colors[score];
    labelEl.textContent = labels[score];
    labelEl.style.color = colors[score];
  }

  // ── Splash ────────────────────────────────────────────────────

  function hideSplash(cb) {
    const splash = document.getElementById("splash-screen");
    if (!splash) { if (cb) cb(); return; }
    splash.classList.add("fade-out");
    splash.addEventListener("transitionend", () => {
      splash.remove();
      if (cb) cb();
    }, { once: true });
  }

  // ── Public API ────────────────────────────────────────────────
  return {
    showToast,
    updateStatus,
    updateSafetyStatus,
    navigateTo,
    initTheme,
    setTheme,
    toggleTheme,
    showAuth,
    showApp,
    switchAuthTab,
    setFieldError,
    clearFormErrors,
    setButtonLoading,
    initSOSButton,
    updatePasswordStrength,
    hideSplash
  };
})();
