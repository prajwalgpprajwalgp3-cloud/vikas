/**
 * SafeHer – voice.js
 * Continuous voice recognition to detect emergency trigger phrases.
 * Uses Web Speech API (SpeechRecognition) – supported in Chrome/Edge.
 * Falls back gracefully on unsupported browsers.
 */

const VoiceModule = (() => {
  // ── State ───────────────────────────────────────────────────
  let recognition = null;
  let isListening = false;
  let restartTimer = null;
  let onTriggerCallback = null;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const isSupported = Boolean(SpeechRecognition);

  // ── Initialization ───────────────────────────────────────────

  function init() {
    if (!isSupported) {
      console.warn("[VoiceModule] SpeechRecognition not supported in this browser.");
      return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous      = true;
    recognition.interimResults  = true;
    recognition.lang            = "en-IN"; // English (India), can be changed
    recognition.maxAlternatives = 3;

    recognition.onstart = () => {
      isListening = true;
      _updateUI(true);
      console.log("[VoiceModule] Listening started.");
    };

    recognition.onend = () => {
      isListening = false;
      _updateUI(false);
      // Auto-restart if we expect to be listening (not manually stopped)
      if (_shouldRestart) {
        restartTimer = setTimeout(() => {
          if (_shouldRestart && recognition) {
            try { recognition.start(); } catch { /* already started */ }
          }
        }, 1000);
      }
    };

    recognition.onerror = (e) => {
      if (e.error === "not-allowed") {
        UI.showToast("Microphone permission denied. Voice activation is disabled.", "error");
        _shouldRestart = false;
        isListening = false;
        _updateUI(false);
      } else if (e.error === "no-speech") {
        // Normal – no speech detected. Continue listening.
      } else {
        console.warn("[VoiceModule] Recognition error:", e.error);
      }
    };

    recognition.onresult = (event) => {
      let transcript = "";

      // Collect all results
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        // Get the most confident alternative
        transcript += result[0].transcript;
        for (let j = 0; j < result.length; j++) {
          transcript += " " + result[j].transcript;
        }
      }

      transcript = transcript.toLowerCase().trim();
      if (transcript) {
        console.log("[VoiceModule] Heard:", transcript);
        _checkTrigger(transcript);
      }
    };
  }

  // ── Control ───────────────────────────────────────────────────

  let _shouldRestart = false;

  function startListening(onTrigger) {
    if (!isSupported) {
      UI.showToast("Voice recognition is not supported in this browser. Try Chrome or Edge.", "warning");
      return false;
    }

    onTriggerCallback = onTrigger;
    _shouldRestart = true;

    if (!recognition) init();

    try {
      if (!isListening) recognition.start();
      UI.showToast("🎙️ Voice activation ON – listening for emergency phrases.", "success");
      return true;
    } catch (e) {
      console.error("[VoiceModule] Could not start:", e);
      return false;
    }
  }

  function stopListening() {
    _shouldRestart = false;
    if (restartTimer) { clearTimeout(restartTimer); restartTimer = null; }

    try {
      if (recognition && isListening) recognition.stop();
    } catch { /* already stopped */ }

    isListening = false;
    _updateUI(false);
    UI.showToast("Voice activation OFF.", "info");
  }

  function toggleListening(onTrigger) {
    if (isListening || _shouldRestart) {
      stopListening();
      return false;
    } else {
      return startListening(onTrigger);
    }
  }

  // ── Trigger Detection ─────────────────────────────────────────

  function _checkTrigger(transcript) {
    const phrases = CONFIG.VOICE_TRIGGER_PHRASES;
    const matched = phrases.find(p => transcript.includes(p));

    if (matched) {
      console.log(`[VoiceModule] TRIGGER detected: "${matched}" in "${transcript}"`);
      _onTriggered(matched);
    }
  }

  let _lastTriggerTime = 0;

  function _onTriggered(phrase) {
    // Debounce: prevent multiple triggers within 10 seconds
    const now = Date.now();
    if (now - _lastTriggerTime < 10000) return;
    _lastTriggerTime = now;

    UI.showToast(`🆘 Voice trigger detected: "${phrase}"! Activating SOS...`, "error");

    // Flash voice indicator
    const indicator = document.getElementById("voice-indicator");
    if (indicator) {
      indicator.style.background = "rgba(229,62,62,0.9)";
      setTimeout(() => { indicator.style.background = ""; }, 2000);
    }

    // Invoke callback (app-level SOS trigger)
    if (typeof onTriggerCallback === "function") {
      onTriggerCallback(phrase);
    } else {
      // Fallback: directly activate SOS
      SOSModule.activateSOS();
    }
  }

  // ── UI Updates ────────────────────────────────────────────────

  function _updateUI(active) {
    const voiceBtn      = document.getElementById("voice-toggle-btn");
    const voiceStatus   = document.getElementById("voice-status");
    const voiceIndicator = document.getElementById("voice-indicator");
    const qaVoiceBtn    = document.getElementById("qa-voice-btn");

    if (voiceBtn) {
      const icon = voiceBtn.querySelector("i");
      if (icon) {
        icon.className = active ? "fas fa-microphone" : "fas fa-microphone-slash";
      }
      voiceBtn.classList.toggle("active-voice", active);
      voiceBtn.title = active ? "Voice Activation: ON" : "Voice Activation: OFF";
    }

    if (voiceStatus) {
      voiceStatus.innerHTML = `<i class="fas fa-microphone"></i><span>Voice: ${active ? "Active" : "Off"}</span>`;
      voiceStatus.classList.toggle("active", active);
    }

    if (voiceIndicator) {
      voiceIndicator.classList.toggle("hidden", !active);
    }

    if (qaVoiceBtn) {
      const icon = qaVoiceBtn.querySelector("i");
      if (icon) icon.style.color = active ? "var(--success)" : "";
    }

    UI.updateStatus("voice-status", active, `Voice: ${active ? "Active" : "Off"}`);
  }

  // ── Public API ────────────────────────────────────────────────
  return {
    startListening,
    stopListening,
    toggleListening,
    isListening() { return isListening; },
    isSupported() { return isSupported; }
  };
})();
