/**
 * SafeHer - location.js
 * Live GPS tracking, Leaflet map rendering, and nearby police station lookup.
 */

const LocationModule = (() => {
  let map = null;
  let userMarker = null;
  let accuracyCircle = null;
  let watchId = null;
  let currentPos = null;
  let policeMarkers = [];
  let routePolylines = [];
  let isTracking = false;
  let hasCenteredOnUser = false;
  let reverseGeocodeToken = 0;
  let lastLowAccuracyToastAt = 0;
  let userIcon = null;
  let policeIcon = null;

  const DEFAULT_CENTER = [12.9716, 77.5946];
  const DEFAULT_LOW_ACCURACY_M = 1000;
  const DEFAULT_STALE_MS = 30000;
  const DEFAULT_RESULT_LIMIT = 0;

  function initMap() {
    if (map) {
      refreshMap();
      return true;
    }

    if (!_hasLeaflet()) {
      UI.showToast("Map library did not load. Check your internet connection and refresh.", "error");
      return false;
    }

    const mapEl = document.getElementById("map");
    if (!mapEl) return false;

    const initialCenter = currentPos ? [currentPos.lat, currentPos.lng] : DEFAULT_CENTER;
    map = L.map(mapEl, {
      center: initialCenter,
      zoom: _zoomForAccuracy(currentPos?.accuracy),
      zoomControl: true,
      attributionControl: true
    });

    L.tileLayer(CONFIG.MAP_TILE_URL, {
      attribution: CONFIG.MAP_ATTRIBUTION,
      maxZoom: 19
    }).addTo(map);

    refreshMap();
    return true;
  }

  function refreshMap() {
    if (!map) return;

    const invalidate = () => map && map.invalidateSize();
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(invalidate);
    setTimeout(invalidate, 150);
    setTimeout(invalidate, 450);
  }

  function startTracking(onUpdate, onError) {
    if (!navigator.geolocation) {
      UI.showToast("Geolocation is not supported by your browser.", "error");
      return false;
    }

    if (isTracking) return true;

    if (!map) initMap();

    const options = {
      enableHighAccuracy: true,
      maximumAge: 0,
      timeout: 20000
    };

    navigator.geolocation.getCurrentPosition(
      pos => _onPositionUpdate(pos, onUpdate, true),
      err => _onPositionError(err, onError),
      options
    );

    watchId = navigator.geolocation.watchPosition(
      pos => _onPositionUpdate(pos, onUpdate),
      err => _onPositionError(err, onError),
      options
    );

    isTracking = true;
    UI.updateStatus("location-status", true, "Location: Searching");
    return true;
  }

  function stopTracking() {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      watchId = null;
    }
    isTracking = false;
    UI.updateStatus("location-status", false, "Location: Inactive");
  }

  function locateOnce() {
    if (!navigator.geolocation) {
      UI.showToast("Geolocation is not supported by your browser.", "error");
      return Promise.resolve(null);
    }

    if (!map) initMap();

    return new Promise(resolve => {
      navigator.geolocation.getCurrentPosition(
        pos => {
          _onPositionUpdate(pos, null, true);
          resolve(currentPos);
        },
        err => {
          _onPositionError(err);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 20000
        }
      );
    });
  }

  async function centerMap() {
    if (!currentPos) {
      UI.showToast("Getting your current location...", "info");
      const pos = await locateOnce();
      if (!pos) {
        UI.showToast("Allow location access first, then try centering the map.", "warning");
        return;
      }
    }

    if (!map) initMap();
    if (!map || !currentPos) return;

    refreshMap();
    _focusUserPosition(currentPos, true);
    hasCenteredOnUser = true;
  }

  async function findNearbyPoliceStations() {
    if (!currentPos) {
      UI.showToast("Getting your current location first...", "info");
      const pos = await locateOnce();
      if (!pos) {
        UI.showToast("Location is needed to find nearby police stations.", "warning");
        return [];
      }
    }

    if (!map) initMap();

    UI.showToast("Searching for nearby police stations...", "info");

    const { lat, lng } = currentPos;
    const radius = CONFIG.MAP_POLICE_SEARCH_RADIUS_M;
    const query = `
      [out:json][timeout:25];
      (
        node["amenity"="police"](around:${radius},${lat},${lng});
        way["amenity"="police"](around:${radius},${lat},${lng});
        relation["amenity"="police"](around:${radius},${lat},${lng});
      );
      out center tags;
    `;

    try {
      const res = await fetch(CONFIG.OVERPASS_API_URL, {
        method: "POST",
        body: "data=" + encodeURIComponent(query)
      });
      if (!res.ok) throw new Error("Overpass API error");

      const data = await res.json();
      const stations = _parsePoliceStations(data.elements || [], lat, lng);

      _clearPoliceMarkers();
      _renderPoliceMarkers(stations);
      _renderPoliceDirections(stations);
      _renderPoliceList(stations);
      _fitPoliceResults(stations);

      if (stations.length === 0) {
        UI.showToast("No named police stations found nearby. Open Maps search for more options.", "warning");
      } else {
        UI.showToast(`Found ${stations.length} nearby police station(s).`, "success");
      }

      return stations;
    } catch (err) {
      console.error("Police search error:", err);
      _clearPoliceMarkers();
      _renderPoliceList([], {
        message: "Police station data could not be loaded right now. Use emergency calling or open Maps search near your live location."
      });
      UI.showToast("Could not load police station data. Try again or open Maps search.", "warning");
      return [];
    }
  }

  function _onPositionUpdate(pos, callback, force = false) {
    const nextPos = _normalizePosition(pos);
    if (!nextPos) return;

    if (!force && !_shouldUsePosition(nextPos)) return;

    currentPos = nextPos;

    if (!map) initMap();
    if (map) {
      _updateUserMarker(currentPos);
      refreshMap();

      if (!hasCenteredOnUser) {
        _focusUserPosition(currentPos, false);
        hasCenteredOnUser = true;
      }
    }

    _updateLocationPanel(currentPos);
    _warnIfLowAccuracy(currentPos);
    UI.updateStatus("location-status", true, "Location: Active");

    if (typeof callback === "function") callback(currentPos);
  }

  function _onPositionError(err, callback) {
    let msg = "Unable to access location.";
    if (err.code === 1) msg = "Location permission denied. Please enable it in browser settings.";
    else if (err.code === 2) msg = "Location unavailable. Check GPS or network signal.";
    else if (err.code === 3) msg = "Location request timed out. Move near a window and try again.";
    UI.showToast(msg, "error");
    UI.updateStatus("location-status", false, "Location: Error");
    if (typeof callback === "function") callback(err);
  }

  function _normalizePosition(pos) {
    const lat = Number(pos?.coords?.latitude);
    const lng = Number(pos?.coords?.longitude);
    const accuracy = Number(pos?.coords?.accuracy);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      UI.showToast("Received an invalid location from the browser.", "error");
      return null;
    }

    return {
      lat,
      lng,
      accuracy: Number.isFinite(accuracy) ? accuracy : 0,
      timestamp: new Date(pos.timestamp || Date.now())
    };
  }

  function _shouldUsePosition(nextPos) {
    if (!currentPos) return true;

    const currentAge = Date.now() - currentPos.timestamp.getTime();
    const staleMs = CONFIG.LOCATION_STALE_MS || DEFAULT_STALE_MS;
    const isMoreAccurate = nextPos.accuracy <= currentPos.accuracy + 25;
    const currentIsStale = currentAge > staleMs;

    return isMoreAccurate || currentIsStale;
  }

  function _updateUserMarker(pos) {
    const latLng = [pos.lat, pos.lng];
    const accuracyText = _formatAccuracy(pos.accuracy);
    const popupHtml = `<strong>You are here</strong><br>Accuracy: ${accuracyText}`;

    if (!userMarker) {
      userMarker = L.marker(latLng, { icon: _getUserIcon(), zIndexOffset: 1000 }).addTo(map);
      userMarker.bindPopup(popupHtml);
    } else {
      userMarker.setLatLng(latLng);
      userMarker.getPopup().setContent(popupHtml);
    }

    const radius = Math.max(pos.accuracy || 0, 10);
    if (!accuracyCircle) {
      accuracyCircle = L.circle(latLng, {
        radius,
        color: "#d63076",
        fillColor: "#d63076",
        fillOpacity: 0.1,
        weight: 1
      }).addTo(map);
    } else {
      accuracyCircle.setLatLng(latLng).setRadius(radius);
    }
  }

  function _focusUserPosition(pos, animate) {
    if (!map) return;

    const latLng = [pos.lat, pos.lng];
    const zoom = _zoomForAccuracy(pos.accuracy);

    if (accuracyCircle && pos.accuracy > 250) {
      map.fitBounds(accuracyCircle.getBounds(), {
        padding: [36, 36],
        maxZoom: zoom,
        animate
      });
      return;
    }

    if (animate) {
      map.flyTo(latLng, zoom, { animate: true, duration: 1 });
    } else {
      map.setView(latLng, zoom);
    }
  }

  function _updateLocationPanel(pos) {
    const el = id => document.getElementById(id);
    if (!el("loc-coords")) return;

    el("loc-coords").textContent = `${pos.lat.toFixed(6)}, ${pos.lng.toFixed(6)}`;
    el("loc-time").textContent = pos.timestamp.toLocaleTimeString();
    if (el("loc-accuracy")) el("loc-accuracy").textContent = _formatAccuracy(pos.accuracy);
    if (el("loc-address")) el("loc-address").textContent = "Finding address...";

    const token = ++reverseGeocodeToken;
    _reverseGeocode(pos.lat, pos.lng).then(address => {
      if (token === reverseGeocodeToken && el("loc-address")) {
        el("loc-address").textContent = address;
      }
    });
  }

  async function _reverseGeocode(lat, lng) {
    try {
      const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
      const res = await fetch(url, { headers: { "Accept-Language": "en" } });
      if (!res.ok) throw new Error("Geocode failed");
      const data = await res.json();
      return data.display_name || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    } catch {
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  }

  function _parsePoliceStations(elements, userLat, userLng) {
    const byKey = new Map();
    const configuredLimit = Number(CONFIG.MAP_POLICE_RESULT_LIMIT);
    const resultLimit = Number.isFinite(configuredLimit) && configuredLimit > 0
      ? configuredLimit
      : DEFAULT_RESULT_LIMIT;

    elements.forEach(item => {
      const coords = _getElementCoords(item);
      if (!coords) return;

      const tags = item.tags || {};
      const name = _getStationName(tags);
      if (!name) return;

      const distance = _haversine(userLat, userLng, coords.lat, coords.lng);
      const station = {
        id: `${item.type || "osm"}-${item.id}`,
        name,
        lat: coords.lat,
        lng: coords.lng,
        phone: _getStationPhone(tags),
        distance
      };

      const key = _stationKey(station);
      const existing = byKey.get(key);
      if (!existing || station.distance < existing.distance) {
        byKey.set(key, station);
      }
    });

    const sortedStations = [...byKey.values()]
      .sort((a, b) => a.distance - b.distance);

    return resultLimit > 0 ? sortedStations.slice(0, resultLimit) : sortedStations;
  }

  function _getElementCoords(item) {
    const lat = Number(item?.lat ?? item?.center?.lat);
    const lng = Number(item?.lon ?? item?.center?.lon);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return { lat, lng };
  }

  function _getStationName(tags) {
    const directName = [
      tags.name,
      tags["name:en"],
      tags.official_name,
      tags["official_name:en"],
      tags.operator,
      tags.brand
    ].find(_isUsableStationName);

    if (directName) return _cleanStationName(directName);

    const areaName = [
      tags["addr:suburb"],
      tags["addr:neighbourhood"],
      tags["addr:city"],
      tags["addr:street"]
    ].find(_isUsableStationName);

    return areaName ? `${_cleanStationName(areaName)} Police Station` : null;
  }

  function _isUsableStationName(value) {
    if (!value || typeof value !== "string") return false;
    const normalized = value.trim().toLowerCase();
    const unusableNames = new Set([
      "not found",
      "not available",
      "unknown",
      "unnamed",
      "police",
      "police station"
    ]);

    return normalized.length > 2 && !unusableNames.has(normalized);
  }

  function _cleanStationName(value) {
    return value.replace(/\s+/g, " ").trim();
  }

  function _getStationPhone(tags) {
    return tags.phone || tags["contact:phone"] || tags["operator:phone"] || null;
  }

  function _stationKey(station) {
    const normalizedName = station.name.toLowerCase().replace(/[^a-z0-9]/g, "");
    const roundedLat = station.lat.toFixed(4);
    const roundedLng = station.lng.toFixed(4);
    return `${normalizedName}-${roundedLat}-${roundedLng}`;
  }

  function _clearPoliceMarkers() {
    policeMarkers.forEach(marker => map && map.removeLayer(marker));
    policeMarkers = [];
    routePolylines.forEach(route => map && map.removeLayer(route));
    routePolylines = [];
  }

  function _renderPoliceMarkers(stations) {
    if (!map) return;

    stations.forEach(station => {
      const phoneLine = station.phone ? `<br>Phone: ${_escapeHTML(station.phone)}` : "";
      const directionsUrl = _googleDirectionsUrl(station);
      const directionsLink = directionsUrl
        ? `<br><a href="${_escapeHTML(directionsUrl)}" target="_blank" rel="noopener noreferrer">Open directions</a>`
        : "";
      const marker = L.marker([station.lat, station.lng], { icon: _getPoliceIcon() })
        .addTo(map)
        .bindPopup(`<strong>${_escapeHTML(station.name)}</strong><br>Distance: ${_formatDist(station.distance)}${phoneLine}${directionsLink}`);
      policeMarkers.push(marker);
    });
  }

  function _renderPoliceDirections(stations) {
    if (!map || !currentPos || stations.length === 0) return;

    stations.forEach((station, index) => {
      const route = L.polyline(
        [
          [currentPos.lat, currentPos.lng],
          [station.lat, station.lng]
        ],
        {
          color: index === 0 ? "#d63076" : "#3182ce",
          weight: index === 0 ? 4 : 3,
          opacity: index === 0 ? 0.85 : 0.45,
          dashArray: index === 0 ? "" : "6 8",
          lineCap: "round"
        }
      ).addTo(map);

      route.bindTooltip(`${station.name} - ${_formatDist(station.distance)}`, {
        sticky: true,
        direction: "top"
      });
      routePolylines.push(route);
    });
  }

  function _fitPoliceResults(stations) {
    if (!map || stations.length === 0 || !currentPos || !_hasLeaflet()) return;

    const points = [L.marker([currentPos.lat, currentPos.lng])].concat(
      stations.map(station => L.marker([station.lat, station.lng]))
    );
    const group = L.featureGroup(points);
    map.fitBounds(group.getBounds(), {
      padding: [42, 42],
      maxZoom: CONFIG.MAP_DEFAULT_ZOOM || 15
    });
  }

  function _renderPoliceList(stations, state = {}) {
    const container = document.getElementById("police-stations-container");
    const listEl = document.getElementById("police-list");
    if (!container || !listEl) return;

    container.replaceChildren();
    listEl.classList.remove("hidden");

    if (stations.length === 0) {
      _renderEmptyPoliceState(container, state.message || "No named police stations were found nearby.");
      return;
    }

    stations.forEach(station => {
      const card = document.createElement("div");
      card.className = "police-card";
      card.setAttribute("role", "button");
      card.tabIndex = 0;

      const icon = document.createElement("div");
      icon.className = "police-icon";
      icon.innerHTML = '<i class="fas fa-building-shield"></i>';

      const info = document.createElement("div");
      info.className = "police-info";

      const name = document.createElement("strong");
      name.textContent = station.name;

      const meta = document.createElement("small");
      meta.textContent = station.phone ? station.phone : `Emergency: ${CONFIG.POLICE_NUMBER}`;

      const distance = document.createElement("div");
      distance.className = "police-distance";
      distance.textContent = _formatDist(station.distance);

      const directionsBtn = document.createElement("button");
      directionsBtn.type = "button";
      directionsBtn.className = "police-directions-btn";
      directionsBtn.title = `Open directions to ${station.name}`;
      directionsBtn.innerHTML = '<i class="fas fa-route"></i><span>Directions</span>';
      directionsBtn.addEventListener("click", event => {
        event.stopPropagation();
        _openDirections(station);
      });

      const actions = document.createElement("div");
      actions.className = "police-actions";
      actions.append(distance, directionsBtn);

      info.append(name, meta);
      card.append(icon, info, actions);

      const focusStation = () => {
        if (!map) return;
        map.flyTo([station.lat, station.lng], 16, { animate: true, duration: 1 });
        policeMarkers.find(marker => _samePoint(marker.getLatLng(), station))?.openPopup();
      };

      card.addEventListener("click", focusStation);
      card.addEventListener("keydown", event => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        focusStation();
      });

      container.appendChild(card);
    });
  }

  function _renderEmptyPoliceState(container, message) {
    const empty = document.createElement("div");
    empty.className = "police-list-message";

    const text = document.createElement("p");
    text.textContent = message;

    const action = document.createElement("button");
    action.type = "button";
    action.className = "btn-outline police-search-link";
    action.innerHTML = '<i class="fas fa-map-location-dot"></i> Open Maps Search';
    action.addEventListener("click", () => {
      const url = _googlePoliceSearchUrl();
      if (!url) return;
      window.open(url, "_blank", "noopener,noreferrer");
    });

    empty.append(text, action);
    container.appendChild(empty);
  }

  function _googlePoliceSearchUrl() {
    if (!currentPos) return "";
    const { lat, lng } = currentPos;
    return `https://www.google.com/maps/search/police+station/@${lat},${lng},15z`;
  }

  function _googleDirectionsUrl(station) {
    if (!currentPos || !station) return "";
    const origin = `${currentPos.lat},${currentPos.lng}`;
    const destination = `${station.lat},${station.lng}`;
    return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=driving`;
  }

  function _openDirections(station) {
    const url = _googleDirectionsUrl(station);
    if (!url) {
      UI.showToast("Enable location first to open directions.", "warning");
      return;
    }

    window.open(url, "_blank", "noopener,noreferrer");
  }

  function _samePoint(latLng, station) {
    return Math.abs(latLng.lat - station.lat) < 0.00001 &&
      Math.abs(latLng.lng - station.lng) < 0.00001;
  }

  function _warnIfLowAccuracy(pos) {
    const threshold = CONFIG.LOCATION_LOW_ACCURACY_M || DEFAULT_LOW_ACCURACY_M;
    if (!pos.accuracy || pos.accuracy <= threshold) return;

    const now = Date.now();
    if (now - lastLowAccuracyToastAt < 30000) return;

    UI.showToast(`GPS accuracy is low (${_formatAccuracy(pos.accuracy)}). Move near a window for better precision.`, "warning", 6000);
    lastLowAccuracyToastAt = now;
  }

  function _zoomForAccuracy(accuracy) {
    if (!accuracy || accuracy <= 100) return 16;
    if (accuracy <= 500) return 15;
    if (accuracy <= 1500) return 14;
    return 13;
  }

  function _formatAccuracy(meters) {
    if (!Number.isFinite(meters) || meters <= 0) return "Unknown";
    return `about ${_formatDist(meters)}`;
  }

  function _formatDist(meters) {
    if (meters < 1000) return `${Math.round(meters)}m`;
    return `${(meters / 1000).toFixed(1)}km`;
  }

  function _haversine(lat1, lng1, lat2, lng2) {
    const earthRadiusM = 6371000;
    const dLat = _toRad(lat2 - lat1);
    const dLng = _toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 +
      Math.cos(_toRad(lat1)) * Math.cos(_toRad(lat2)) *
      Math.sin(dLng / 2) ** 2;

    return earthRadiusM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function _toRad(deg) {
    return deg * Math.PI / 180;
  }

  function _escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    }[char]));
  }

  function _hasLeaflet() {
    return typeof window !== "undefined" && typeof window.L !== "undefined";
  }

  function _getUserIcon() {
    if (userIcon) return userIcon;

    userIcon = L.divIcon({
      className: "",
      html: `<div style="
        width:20px;height:20px;
        background:linear-gradient(135deg,#a8215a,#d63076);
        border-radius:50%;
        border:3px solid #fff;
        box-shadow:0 2px 12px rgba(214,48,118,0.5);
        position:relative;
      ">
        <div style="
          position:absolute;top:50%;left:50%;
          transform:translate(-50%,-50%);
          width:8px;height:8px;
          background:#fff;border-radius:50%;
        "></div>
      </div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    return userIcon;
  }

  function _getPoliceIcon() {
    if (policeIcon) return policeIcon;

    policeIcon = L.divIcon({
      className: "",
      html: `<div style="
        width:32px;height:32px;
        background:linear-gradient(135deg,#1a54a5,#3182ce);
        border-radius:8px;
        border:2px solid #fff;
        box-shadow:0 2px 10px rgba(49,130,206,0.4);
        display:flex;align-items:center;justify-content:center;
        color:#fff;font-size:14px;
      "><i class="fas fa-building-shield"></i></div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 32]
    });

    return policeIcon;
  }

  return {
    initMap,
    refreshMap,
    startTracking,
    stopTracking,
    locateOnce,
    centerMap,
    findNearbyPoliceStations,
    getCurrentPosition() { return currentPos; },
    isTracking() { return isTracking; },
    getMap() { return map; }
  };
})();
